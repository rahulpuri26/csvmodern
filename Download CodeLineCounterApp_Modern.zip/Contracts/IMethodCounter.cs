namespace CodeLineCounterApp.Contracts;

public interface IMethodCounter
{
    Task<int> CountMethodsAsync(string code);
}