namespace CodeLineCounterApp.Contracts;

public interface ILineCounter
{
    Task<int> CountLinesAsync(string filePath);
}