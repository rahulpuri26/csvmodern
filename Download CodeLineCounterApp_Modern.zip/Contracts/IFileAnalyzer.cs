using CodeLineCounterApp.Models;

namespace CodeLineCounterApp.Contracts;

public interface IFileAnalyzer
{
    Task<(List<FileAnalysisResult> Results, SummaryResult Summary)> AnalyzeAsync(AppSettings settings, string rootPath, bool includeSubfolders);
}