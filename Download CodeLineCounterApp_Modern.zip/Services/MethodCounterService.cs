using CodeLineCounterApp.Contracts;
using System.Text.RegularExpressions;

namespace CodeLineCounterApp.Services;

public class MethodCounterService : IMethodCounter
{
    public Task<int> CountMethodsAsync(string code)
    {
        var regex = new Regex(@"(?:public|private|protected|internal|static|virtual|\s)+\s+\w[\w\d_<>]*\s+\w+\s*\([^)]*\)\s*{");
        var count = regex.Matches(code).Count;
        return Task.FromResult(count);
    }
}