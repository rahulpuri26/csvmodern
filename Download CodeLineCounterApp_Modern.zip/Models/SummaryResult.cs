namespace CodeLineCounterApp.Models;

public class SummaryResult
{
    public int TotalFiles { get; set; }
    public int TotalLines { get; set; }
    public int TotalMethods { get; set; }
}