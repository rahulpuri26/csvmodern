﻿namespace CodeLineCounterApp.Models
{
    public class ComplexityResult
    {
        public string FileName { get; set; } = string.Empty;
        // Cyclomatic Complexity (number of control flow decisions + 1)
        public int CyclomaticComplexity { get; set; }
        // Class Coupling (unique external types referenced)
        public int ClassCoupling { get; set; }
        // Optional: Used for summary calculations
        public string ComplexityCategory { get; set; }
        // Classification based on complexity score
        public string ComplexityLevel
        {
            get
            {
                return CyclomaticComplexity switch
                {
                    <= 10 => "Low",
                    <= 20 => "Medium",
                    <= 30 => "High",
                    _ => "Very High"
                };
            }
        }
    }
}