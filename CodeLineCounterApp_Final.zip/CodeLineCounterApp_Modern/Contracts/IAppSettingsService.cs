﻿using CodeLineCounterApp.Models;
namespace CodeLineCounterApp.Services;
public interface IAppSettingsService
{
    void SaveLastUsedConfigPath(string path);
    string? LoadLastUsedConfigPath();
    void SaveAppSettings(string path, AppSettings settings);
    AppSettings? LoadAppSettings(string path);
}