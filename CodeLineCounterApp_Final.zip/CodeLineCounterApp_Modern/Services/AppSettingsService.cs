﻿using CodeLineCounterApp.Models;
using System.IO;
using System.Text.Json;
namespace CodeLineCounterApp.Services;
public class AppSettingsService : IAppSettingsService
{
    private const string LastUsedPathFile = "lastusedconfig.json";
    public void SaveLastUsedConfigPath(string path)
    {
        var json = JsonSerializer.Serialize(new { LastUsedConfigPath = path });
        File.WriteAllText(LastUsedPathFile, json);
    }
    public string? LoadLastUsedConfigPath()
    {
        if (!File.Exists(LastUsedPathFile))
            return null;
        var json = File.ReadAllText(LastUsedPathFile);
        using var doc = JsonDocument.Parse(json);
        if (doc.RootElement.TryGetProperty("LastUsedConfigPath", out var prop))
            return prop.GetString();
        return null;
    }
    public void SaveAppSettings(string path, AppSettings settings)
    {
        var json = JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(path, json);
    }
    public AppSettings? LoadAppSettings(string path)
    {
        if (!File.Exists(path))
            return null;
        var json = File.ReadAllText(path);
        return JsonSerializer.Deserialize<AppSettings>(json);
    }
}