﻿using CodeLineCounterApp.Contracts;
using CodeLineCounterApp.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
namespace CodeLineCounterApp.Services
{
    public class FileAnalyzerService(
        ILineCounter lineCounter,
        IMethodCounter methodCounter,
        IComplexityAnalyzer complexityAnalyzer,
        ILoggerService logger) : IFileAnalyzer
    {
        public async Task<List<FileAnalysisResult>> AnalyzeFilesAsync(AppSettings settings, string rootPath, bool includeSubfolders)
        {
            var results = new List<FileAnalysisResult>();
            string[] allFiles;
            try
            {
                if (!Directory.Exists(rootPath))
                    throw new DirectoryNotFoundException($"Directory '{rootPath}' does not exist.");
                allFiles = Directory.GetFiles(rootPath, "*.*",
                    includeSubfolders ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
            }
            catch (Exception ex)
            {
                logger.LogError("Failed to list files: {Message}", ex.Message);
                return results;
            }
            var filteredFiles = allFiles
                .Where(file =>
                    (settings.IncludedExtensions.Count == 0 || settings.IncludedExtensions.Contains(Path.GetExtension(file))) &&
                    !settings.ExcludedPaths.Any(p => file.Contains(p)))
                .ToList();
            logger.LogInfo("Starting line analysis...");
            foreach (var file in filteredFiles)
            {
                try
                {
                    int lineCount = await lineCounter.CountLinesAsync(file);
                    results.Add(new FileAnalysisResult
                    {
                        FileName = Path.GetFileName(file),
                        FullPath = file,
                        Extension = Path.GetExtension(file),
                        LineCount = lineCount
                    });
                }
                catch (Exception ex)
                {
                    logger.LogError("Line count failed for {File}: {Error}", file, ex.Message);
                }
            }
            logger.LogInfo("Line analysis completed.");
            logger.LogInfo("Starting method and complexity analysis...");
            foreach (var result in results)
            {
                try
                {
                    string code = await File.ReadAllTextAsync(result.FullPath);
                    // Method count
                    int methodCount = await methodCounter.CountMethodsAsync(code);
                    result.MethodCount = methodCount;
                    // Complexity
                    var complexity = await complexityAnalyzer.AnalyzeAsync(result.FullPath, code);
                    result.CyclomaticComplexity = complexity.CyclomaticComplexity;
                    result.ClassCoupling = complexity.ClassCoupling;
                }
                catch (Exception ex)
                {
                    logger.LogError("Analysis failed for {File}: {Error}", result.FullPath, ex.Message);
                }
            }
            logger.LogInfo("Method and complexity analysis completed.");
            return results;
        }
    }
}