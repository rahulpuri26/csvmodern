﻿using CodeLineCounterApp.Contracts;
using CodeLineCounterApp.Models;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
namespace CodeLineCounterApp.Services
{
    public class ComplexityAnalyzerService : IComplexityAnalyzer
    {
        private static readonly string[] CommonTypesToIgnore =
        [
            "int", "string", "float", "double", "decimal", "bool", "var", "object",
           "Task", "void", "List", "IEnumerable", "HashSet", "Dictionary"
        ];
        public Task<ComplexityResult> AnalyzeAsync(string filePath, string code)
        {
            var tree = CSharpSyntaxTree.ParseText(code);
            var root = tree.GetRoot();
            var compilation = CSharpCompilation.Create("Analysis")
                .AddSyntaxTrees(tree)
                .AddReferences(
                    MetadataReference.CreateFromFile(typeof(object).Assembly.Location),
                    MetadataReference.CreateFromFile(typeof(Enumerable).Assembly.Location),
                    MetadataReference.CreateFromFile(typeof(List<>).Assembly.Location),
                    MetadataReference.CreateFromFile(typeof(Task).Assembly.Location)
                );
            var model = compilation.GetSemanticModel(tree);
            int cyclomatic = CalculateCyclomaticComplexity(root);
            int coupling = CalculateClassCoupling(root, model, Path.GetFileNameWithoutExtension(filePath));
            var bucket = ClassifyComplexityBucket(cyclomatic);
            return Task.FromResult(new ComplexityResult
            {
                FileName = Path.GetFileName(filePath),
                CyclomaticComplexity = cyclomatic,
                ClassCoupling = coupling,
                ComplexityCategory = bucket
            });
        }
        private static int CalculateCyclomaticComplexity(SyntaxNode root)
        {
            int complexity = 0;
            var functionNodes = root.DescendantNodes().Where(n =>
                n is MethodDeclarationSyntax or
                    LocalFunctionStatementSyntax or
                    AnonymousMethodExpressionSyntax or
                    SimpleLambdaExpressionSyntax or
                    ParenthesizedLambdaExpressionSyntax);
            foreach (var node in functionNodes)
            {
                int count = 1; // base complexity
                count += node.DescendantNodes().OfType<IfStatementSyntax>().Count();
                count += node.DescendantNodes().OfType<ForStatementSyntax>().Count();
                count += node.DescendantNodes().OfType<ForEachStatementSyntax>().Count();
                count += node.DescendantNodes().OfType<WhileStatementSyntax>().Count();
                count += node.DescendantNodes().OfType<DoStatementSyntax>().Count();
                count += node.DescendantNodes().OfType<CaseSwitchLabelSyntax>().Count();
                count += node.DescendantNodes().OfType<CatchClauseSyntax>().Count();
                count += node.DescendantNodes().OfType<ConditionalExpressionSyntax>().Count();
                count += node.DescendantNodes().OfType<BinaryExpressionSyntax>()
                    .Count(be => be.IsKind(SyntaxKind.LogicalAndExpression) || be.IsKind(SyntaxKind.LogicalOrExpression));
                complexity += count;
            }
            return complexity;
        }
        private static int CalculateClassCoupling(SyntaxNode root, SemanticModel model, string currentClassName)
        {
            var typeSymbols = new HashSet<string>();
            foreach (var node in root.DescendantNodes().OfType<ExpressionSyntax>())
            {
                var typeInfo = model.GetTypeInfo(node);
                if (typeInfo.Type is ITypeSymbol typeSymbol && IsValidType(typeSymbol, currentClassName))
                {
                    typeSymbols.Add(typeSymbol.ToDisplayString());
                }
            }
            foreach (var decl in root.DescendantNodes().OfType<VariableDeclarationSyntax>())
            {
                var type = model.GetTypeInfo(decl.Type).Type;
                if (type is ITypeSymbol symbol && IsValidType(symbol, currentClassName))
                {
                    typeSymbols.Add(symbol.ToDisplayString());
                }
            }
            foreach (var objCreate in root.DescendantNodes().OfType<ObjectCreationExpressionSyntax>())
            {
                var type = model.GetTypeInfo(objCreate).Type;
                if (type is ITypeSymbol symbol && IsValidType(symbol, currentClassName))
                {
                    typeSymbols.Add(symbol.ToDisplayString());
                }
            }
            return typeSymbols.Count;
        }
        private static bool IsValidType(ITypeSymbol symbol, string currentClassName)
        {
            if (symbol == null) return false;
            string name = symbol.Name;
            return !string.IsNullOrWhiteSpace(name) &&
                   name != currentClassName &&
                   !CommonTypesToIgnore.Contains(name) &&
                   !IsCSharpKeyword(name);
        }
        private static bool IsCSharpKeyword(string name)
        {
            string[] keywords =
            [
                "namespace", "class", "interface", "enum", "struct",
               "public", "private", "protected", "internal", "static",
               "return", "new", "null", "true", "false", "using", "try",
               "catch", "finally", "switch", "case", "default", "break", "continue"
            ];
            return keywords.Contains(name);
        }
        private static string ClassifyComplexityBucket(int complexity) => complexity switch
        {
            <= 10 => "Low",
            <= 20 => "Medium",
            <= 30 => "High",
            _ => "Very High"
        };
    }
}