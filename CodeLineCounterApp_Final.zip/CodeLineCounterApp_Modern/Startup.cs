﻿using CodeLineCounterApp.Contracts;
using CodeLineCounterApp.Services;
using CodeLineCounterApp.ViewModels;
using CodeLineCounterApp.Views;
using Microsoft.Extensions.DependencyInjection;
namespace CodeLineCounterApp
{
    public static class ServiceConfigurator
    {
        public static void ConfigureServices(IServiceCollection services)
        {
            // Register ViewModels
            services.AddSingleton<MainViewModel>();
            // Register Services
            services.AddSingleton<ILineCounter, LineCounterService>();
            services.AddSingleton<IMethodCounter, MethodCounterService>();
            services.AddSingleton<IFileAnalyzer, FileAnalyzerService>();
            services.AddSingleton<IComplexityAnalyzer, ComplexityAnalyzerService>();
            services.AddSingleton<IAppSettingsService, AppSettingsService>();
            services.AddSingleton<ILoggerService, SerilogLoggerService>();
           

            // Register Views
            services.AddSingleton<MainWindow>(provider =>
            {
                return new MainWindow
                {
                    DataContext = provider.GetRequiredService<MainViewModel>()
                };
            });
        }
    }
}