﻿using CodeLineCounterApp.Contracts;
using CodeLineCounterApp.Models;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
namespace CodeLineCounterApp.Services
{
    public class ComplexityAnalyzerService : IComplexityAnalyzer
    {
        public Task<ComplexityResult> AnalyzeAsync(string filePath, string code)
        {
            // Estimate cyclomatic complexity based on branching logic
            int complexity = Regex.Matches(code, @"\b(if|else if|for|foreach|while|case|catch|&&|\|\|)\b").Count + 1;
            // Estimate class coupling by counting unique referenced class names
            string currentClass = Path.GetFileNameWithoutExtension(filePath);
            int coupling = Regex.Matches(code, @"\b[A-Z][a-zA-Z0-9_]*\b")
                .Cast<Match>()
                .Select(m => m.Value)
                .Where(name => name != currentClass)
                .Distinct()
                .Count();
            return Task.FromResult(new ComplexityResult
            {
                FileName = Path.GetFileName(filePath),
                CyclomaticComplexity = complexity,
                ClassCoupling = coupling
            });
        }
    }
}