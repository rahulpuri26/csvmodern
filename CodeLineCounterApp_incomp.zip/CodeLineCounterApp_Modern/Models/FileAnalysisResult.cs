namespace CodeLineCounterApp.Models;

public class FileAnalysisResult
{
    public string FileName { get; set; } = string.Empty;
    public string FullPath { get; set; } = string.Empty;
    public string Extension { get; set; } = string.Empty;
    public int LineCount { get; set; }
    public int MethodCount { get; set; }
    public int CyclomaticComplexity { get; set; }  
    public int ClassCoupling { get; set; }
}