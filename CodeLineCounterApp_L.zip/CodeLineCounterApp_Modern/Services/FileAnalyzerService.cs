﻿using CodeLineCounterApp.Contracts;
using CodeLineCounterApp.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
namespace CodeLineCounterApp.Services
{
    public class FileAnalyzerService : IFileAnalyzer
    {
        private readonly ILineCounter _lineCounter;
        private readonly IMethodCounter _methodCounter;
        private readonly ILoggerService _logger;
        public FileAnalyzerService(
            ILineCounter lineCounter,
            IMethodCounter methodCounter,
            ILoggerService logger)
        {
            _lineCounter = lineCounter;
            _methodCounter = methodCounter;
            _logger = logger;
        }
        public async Task<List<FileAnalysisResult>> AnalyzeFilesAsync(AppSettings settings, string rootPath, bool includeSubfolders)
        {
            var results = new List<FileAnalysisResult>();
            var allFiles = Directory.GetFiles(rootPath, "*.*",
                includeSubfolders ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
            var filteredFiles = allFiles
                .Where(file =>
                    (settings.IncludedExtensions.Count == 0 || settings.IncludedExtensions.Contains(Path.GetExtension(file))) &&
                    !settings.ExcludedPaths.Any(p => file.Contains(p)))
                .ToList();
            _logger.LogInfo("Starting line analysis...");
            foreach (var file in filteredFiles)
            {
                string code = await File.ReadAllTextAsync(file);
                int lineCount = await _lineCounter.CountLinesAsync(file);
                results.Add(new FileAnalysisResult
                {
                    FileName = Path.GetFileName(file),
                    FullPath = file,
                    Extension = Path.GetExtension(file),
                    LineCount = lineCount
                });
            }
            _logger.LogInfo("Line analysis completed.");
            _logger.LogInfo("Starting method analysis...");
            foreach (var result in results)
            {
                string code = await File.ReadAllTextAsync(result.FullPath);
                int methodCount = await _methodCounter.CountMethodsAsync(code);
                result.MethodCount = methodCount;
            }
            _logger.LogInfo("Method analysis completed.");
            return results;
        }
    }
}