﻿using CodeLineCounterApp.Contracts;
using CodeLineCounterApp.Helpers;
using CodeLineCounterApp.Models;
using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Forms;
using SaveFileDialog = System.Windows.Forms.SaveFileDialog;
using OpenFileDialog = Microsoft.Win32.OpenFileDialog;
using CodeLineCounterApp.Configuration;
using CodeLineCounterApp.Services;
namespace CodeLineCounterApp.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private readonly IFileAnalyzer fileAnalyzer;
        private readonly ILoggerService logger;
        private readonly IAppSettingsService _appSettingsService;
        private string _rootPath = string.Empty;
        private bool _includeSubfolders = true;
        private string _manualExtensions = "";
        private string _manualExcludedPaths = "";
        private int _totalLineCount;
        private int _totalFileCount;
        private int _totalMethodCount;
        private int _lowComplexityFiles;
        private int _mediumComplexityFiles;
        private int _highComplexityFiles;
        private int _veryHighComplexityFiles;
        private string _overallComplexityLevel = string.Empty;
        private string _loadedConfigFileName = string.Empty;
        private string _loadedIncludedExtensionsDisplay;
        private string _loadedExcludedPathsDisplay;
        private string _loadedConfigFilePath = string.Empty;

        public string RootPath
        {
            get => _rootPath;
            set { _rootPath = value; OnPropertyChanged(); }
        }
        public bool IncludeSubfolders
        {
            get => _includeSubfolders;
            set { _includeSubfolders = value; OnPropertyChanged(); }
        }
        public string ManualExtensions
        {
            get => _manualExtensions;
            set { _manualExtensions = value; OnPropertyChanged(); }
        }
        public string ManualExcludedPaths
        {
            get => _manualExcludedPaths;
            set { _manualExcludedPaths = value; OnPropertyChanged(); }
        }
        public int TotalLineCount
        {
            get => _totalLineCount;
            set { _totalLineCount = value; OnPropertyChanged(); }
        }
        public int TotalFileCount
        {
            get => _totalFileCount;
            set { _totalFileCount = value; OnPropertyChanged(); }
        }
        public int TotalMethodCount
        {
            get => _totalMethodCount;
            set { _totalMethodCount = value; OnPropertyChanged(); }
        }
       
        public int LowComplexityFiles
        {
            get => _lowComplexityFiles;
            set { _lowComplexityFiles = value; OnPropertyChanged(); }
        }
        public int MediumComplexityFiles
        {
            get => _mediumComplexityFiles;
            set { _mediumComplexityFiles = value; OnPropertyChanged(); }
        }
        public int HighComplexityFiles
        {
            get => _highComplexityFiles;
            set { _highComplexityFiles = value; OnPropertyChanged(); }
        }
        public int VeryHighComplexityFiles
        {
            get => _veryHighComplexityFiles;
            set { _veryHighComplexityFiles = value; OnPropertyChanged(); }
        }
        public string OverallComplexityLevel
        {
            get => _overallComplexityLevel;
            set { _overallComplexityLevel = value; OnPropertyChanged(); }
        }
        public string LoadedConfigFileName
        {
            get => _loadedConfigFileName;
            set
            {
                _loadedConfigFileName = value;
                OnPropertyChanged(nameof(LoadedConfigFileName));
            }
        }
        public string LoadedIncludedExtensionsDisplay
        {
            get => _loadedIncludedExtensionsDisplay;
            set
            {
                _loadedIncludedExtensionsDisplay = value;
                OnPropertyChanged(nameof(LoadedIncludedExtensionsDisplay));
            }
        }
        public string LoadedExcludedPathsDisplay
        {
            get => _loadedExcludedPathsDisplay;
            set
            {
                _loadedExcludedPathsDisplay = value;
                OnPropertyChanged(nameof(LoadedExcludedPathsDisplay));
            }
        }
        public ObservableCollection<FileAnalysisResult> Results { get; } = [];
        public ICommand AnalyzeCommand => new RelayCommand(async _ => await AnalyzeAsync());
        public ICommand ExportCommand => new RelayCommand(_ => ExportCsv());
        public ICommand LoadJsonCommand => new RelayCommand(_ => LoadJson());
        public ICommand SaveJsonCommand => new RelayCommand(_ => SaveJson());
        public ICommand BrowseFolderCommand => new RelayCommand(_ => BrowseFolder());
        public MainViewModel(IFileAnalyzer fileAnalyzer, ILoggerService logger, IAppSettingsService appSettingsService)
        {
            this.fileAnalyzer = fileAnalyzer;
            this.logger = logger;
            _appSettingsService = appSettingsService;
            LoadLastUsedOrDefaultConfig();
        }
      
        private void LoadLastUsedOrDefaultConfig()
        {
            string configPath = _appSettingsService.LoadLastUsedConfigPath();
            if (string.IsNullOrWhiteSpace(configPath) || !File.Exists(configPath))
            {
                configPath = DefaultFilter.DefaultConfigPath;
            }
            if (!File.Exists(configPath))
                return;
            try
            {
                string json = File.ReadAllText(configPath);
                var config = JsonSerializer.Deserialize<AppSettings>(json);
                if (config == null)
                    return;
               
                ManualExtensions = string.Join("\n", config.IncludedExtensions);
                ManualExcludedPaths = string.Join("\n", config.ExcludedPaths);
               
                _appSettingsService.SaveLastUsedConfigPath(configPath);
               
                LoadedConfigFileName = Path.GetFileName(configPath);
                LoadedIncludedExtensionsDisplay = string.Join(", ", config.IncludedExtensions);
                LoadedExcludedPathsDisplay = string.Join(", ", config.ExcludedPaths);
            }
            catch (Exception ex)
            {
                logger.LogError($"Error loading default config: {ex.Message}");
            }
        }
        private async Task AnalyzeAsync()
        {
            try
            {
                Results.Clear();
                TotalFileCount = 0;
                TotalLineCount = 0;
                TotalMethodCount = 0;
                LowComplexityFiles = 0;
                MediumComplexityFiles = 0;
                HighComplexityFiles = 0;
                VeryHighComplexityFiles = 0;
                if (!Directory.Exists(RootPath)) return;
                var settings = new AppSettings
                {
                    IncludedExtensions = [.. ManualExtensions
                      .Split(['\n', '\r', ',', ';'], StringSplitOptions.RemoveEmptyEntries)
                      .Select(e => e.Trim())
                      .Where(e => e.StartsWith("."))],
                    ExcludedPaths = [.. ManualExcludedPaths
                      .Split(['\n', '\r', ',', ';'], StringSplitOptions.RemoveEmptyEntries)
                      .Select(e => e.Trim())]
                };
                var results = await fileAnalyzer.AnalyzeFilesAsync(settings, RootPath, IncludeSubfolders);
                foreach (var r in results)
                {
                    Results.Add(r);
                    TotalLineCount += r.LineCount;
                    TotalMethodCount += r.MethodCount;
                }
                TotalFileCount = results.Count;
                if (results.Count > 0)
                {
                    LowComplexityFiles = results.Count(r => r.CyclomaticComplexity <= 10);
                    MediumComplexityFiles = results.Count(r => r.CyclomaticComplexity > 10 && r.CyclomaticComplexity <= 20);
                    HighComplexityFiles = results.Count(r => r.CyclomaticComplexity > 20 && r.CyclomaticComplexity <= 30);
                    VeryHighComplexityFiles = results.Count(r => r.CyclomaticComplexity > 30);
                    OverallComplexityLevel = GetOverallComplexityLevel();
                }
                logger.LogInfo("Analysis completed. {FileCount} files analyzed.", TotalFileCount);
            }
            catch (Exception ex)
            {
                logger.LogError("Analysis failed: {Message}", ex.Message);
            }
        }
        private string GetOverallComplexityLevel()
        {
            double weight =
                LowComplexityFiles * 1 +
                MediumComplexityFiles * 2 +
                HighComplexityFiles * 3 +
                VeryHighComplexityFiles * 4;
            if (TotalFileCount == 0) return "Unknown";
            double averageWeight = weight / TotalFileCount;
            return averageWeight switch
            {
                <= 1.5 => "Low",
                <= 2.5 => "Medium",
                <= 3.5 => "High",
                _ => "Very High"
            };
        }
        private void ExportCsv()
        {
            var dialog = new SaveFileDialog { Filter = DefaultFilter.CsvExportFilter, FileName = DefaultFilter.DefaultCsvFileName };
            if (dialog.ShowDialog() != DialogResult.OK) return;
            using var writer = new StreamWriter(dialog.FileName);
            writer.WriteLine("FullPath,FileName,Extension,LineCount,MethodCount,CyclomaticComplexity,ClassCoupling");
            foreach (var r in Results)
            {
                writer.WriteLine($"{r.FullPath},{r.FileName},{r.Extension},{r.LineCount},{r.MethodCount},{r.CyclomaticComplexity},{r.ClassCoupling}");
            }
            writer.WriteLine($",,,Total Files,{TotalFileCount}");
            writer.WriteLine($",,,Total Lines,{TotalLineCount}");
            writer.WriteLine($",,,Total Methods,{TotalMethodCount}");
            writer.WriteLine($",,,Low Complexity Files (≤10),{LowComplexityFiles}");
            writer.WriteLine($",,,Medium Complexity Files (11–20),{MediumComplexityFiles}");
            writer.WriteLine($",,,High Complexity Files (21–30),{HighComplexityFiles}");
            writer.WriteLine($",,,Very High Complexity Files (>30),{VeryHighComplexityFiles}");
            writer.WriteLine($",,,Overall Project Complexity,{OverallComplexityLevel}");
            logger.LogInfo("CSV export completed.");
        }
        private void LoadJson()
        {
            var dialog = new OpenFileDialog { Filter = DefaultFilter.JsonConfigFilter };
            if (dialog.ShowDialog() != true) return;
            var json = File.ReadAllText(dialog.FileName);
            var config = JsonSerializer.Deserialize<AppSettings>(json);
            if (config == null) return;
            ManualExtensions = string.Join("\n", config.IncludedExtensions);
            ManualExcludedPaths = string.Join("\n", config.ExcludedPaths);
            _loadedConfigFilePath = dialog.FileName; 
            _appSettingsService.SaveLastUsedConfigPath(_loadedConfigFilePath); 
            LoadedConfigFileName = Path.GetFileName(_loadedConfigFilePath);
                                                                           
            LoadedIncludedExtensionsDisplay = string.Join(", ", config.IncludedExtensions);
            LoadedExcludedPathsDisplay = string.Join(", ", config.ExcludedPaths);
            logger.LogInfo("Config loaded from JSON.");
        }
        private void SaveJson()
        {
            var dialog = new SaveFileDialog { Filter = DefaultFilter.JsonConfigFilter, FileName = DefaultFilter.DefaultJsonFileName };
            if (dialog.ShowDialog() != DialogResult.OK) return;
            var config = new AppSettings
            {
                IncludedExtensions = ManualExtensions
                    .Split(new[] { '\n', '\r', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(e => e.Trim()).ToList(),
                ExcludedPaths = ManualExcludedPaths
                    .Split(new[] { '\n', '\r', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(e => e.Trim()).ToList()
            };
            var json = JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(dialog.FileName, json);
            _appSettingsService.SaveLastUsedConfigPath(dialog.FileName);
            logger.LogInfo("Config saved to JSON.");
        }
        private void BrowseFolder()
        {
            using var dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                RootPath = dialog.SelectedPath;
                logger.LogInfo("Folder selected: {Path}", RootPath);
            }
        }
    }
}