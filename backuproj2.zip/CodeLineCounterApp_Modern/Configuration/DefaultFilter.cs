﻿namespace CodeLineCounterApp.Configuration;

public static class DefaultFilter
{
    public const string DefaultLogFile = "logs/log.txt";
    public const string DefaultCsvFileName = "results.csv";
    public const string DefaultJsonFileName = "config.csv";
    public const string JsonConfigFilter = "JSON file (*.json)|*.json";
    public const string CsvExportFilter = "CSV file (*.csv)|*.csv";

    public const string DefaultConfigPath = "defaultConfig.json";
}