﻿namespace CodeLineCounterApp.Services.Interfaces;
public interface ILastUsedConfigService
{
    string? GetLastUsedConfigPath();
    void SetLastUsedConfigPath(string path);
}