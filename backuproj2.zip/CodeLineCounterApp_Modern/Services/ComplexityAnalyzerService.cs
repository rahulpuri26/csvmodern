﻿using CodeLineCounterApp.Contracts;
using CodeLineCounterApp.Models;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
namespace CodeLineCounterApp.Services
{
    public class ComplexityAnalyzerService : IComplexityAnalyzer
    {
        private static readonly string[] CommonTypesToIgnore =
        [
            "int", "string", "float", "double", "decimal", "bool", "var", "object",
           "Task", "void", "List", "IEnumerable", "HashSet", "Dictionary"
        ];
        public Task<ComplexityResult> AnalyzeAsync(string filePath, string code)
        {
            var tree = CSharpSyntaxTree.ParseText(code);
            var root = tree.GetRoot();
            var compilation = CSharpCompilation.Create("Analysis")
                .AddSyntaxTrees(tree)
                .AddReferences(
                    MetadataReference.CreateFromFile(typeof(object).Assembly.Location),
                    MetadataReference.CreateFromFile(typeof(Enumerable).Assembly.Location)
                );
            var model = compilation.GetSemanticModel(tree);
            int cyclomatic = CalculateCyclomaticComplexity(root);
            int coupling = CalculateClassCoupling(root, model, Path.GetFileNameWithoutExtension(filePath));
            var bucket = ClassifyComplexityBucket(cyclomatic);
            return Task.FromResult(new ComplexityResult
            {
                FileName = Path.GetFileName(filePath),
                CyclomaticComplexity = cyclomatic,
                ClassCoupling = coupling,
                ComplexityCategory = bucket
            });
        }
        private static int CalculateCyclomaticComplexity(SyntaxNode root)
        {
            int complexity = 0;
            var functionNodes = root.DescendantNodes().Where(n =>
                n is MethodDeclarationSyntax ||
                n is LocalFunctionStatementSyntax ||
                n is AnonymousMethodExpressionSyntax ||
                n is SimpleLambdaExpressionSyntax ||
                n is ParenthesizedLambdaExpressionSyntax);
            foreach (var node in functionNodes)
            {
                int count = 1; // base complexity per method/lambda
                count += node.DescendantNodes().OfType<IfStatementSyntax>().Count();
                count += node.DescendantNodes().OfType<ForStatementSyntax>().Count();
                count += node.DescendantNodes().OfType<ForEachStatementSyntax>().Count();
                count += node.DescendantNodes().OfType<WhileStatementSyntax>().Count();
                count += node.DescendantNodes().OfType<DoStatementSyntax>().Count();
                count += node.DescendantNodes().OfType<CaseSwitchLabelSyntax>().Count();
                count += node.DescendantNodes().OfType<CatchClauseSyntax>().Count();
                count += node.DescendantNodes().OfType<ConditionalExpressionSyntax>().Count(); // ternary ?: operator
                count += node.DescendantNodes().OfType<BinaryExpressionSyntax>()
                    .Count(be => be.IsKind(SyntaxKind.LogicalAndExpression) || be.IsKind(SyntaxKind.LogicalOrExpression));
                complexity += count;
            }
            return complexity;
        }
        private static int CalculateClassCoupling(SyntaxNode root, SemanticModel model, string currentClassName)
        {
            var typeSymbols = new HashSet<string>();
            // 1. IdentifierNameSyntax
            foreach (var identifier in root.DescendantNodes().OfType<IdentifierNameSyntax>())
            {
                var symbol = model.GetSymbolInfo(identifier).Symbol;
                if (symbol is ITypeSymbol typeSymbol && IsValidType(typeSymbol, currentClassName))
                {
                    typeSymbols.Add(typeSymbol.Name);
                }
                else if (symbol is INamedTypeSymbol named && IsValidType(named, currentClassName))
                {
                    typeSymbols.Add(named.Name);
                }
            }
            // 2. Object creation expressions
            foreach (var newExpr in root.DescendantNodes().OfType<ObjectCreationExpressionSyntax>())
            {
                var type = model.GetTypeInfo(newExpr).Type;
                if (type is INamedTypeSymbol named && IsValidType(named, currentClassName))
                {
                    typeSymbols.Add(named.Name);
                }
            }
            // 3. Generic type usages
            foreach (var generic in root.DescendantNodes().OfType<TypeArgumentListSyntax>())
            {
                foreach (var typeArg in generic.Arguments)
                {
                    var symbol = model.GetTypeInfo(typeArg).Type;
                    if (symbol is INamedTypeSymbol named && IsValidType(named, currentClassName))
                    {
                        typeSymbols.Add(named.Name);
                    }
                }
            }
            return typeSymbols.Count;
        }
        private static bool IsValidType(ITypeSymbol symbol, string currentClassName)
        {
            if (symbol == null) return false;
            string name = symbol.Name;
            return !string.IsNullOrWhiteSpace(name)
 && name != currentClassName
 && !CommonTypesToIgnore.Contains(name)
 && !IsCSharpKeyword(name);
        }
        private static bool IsCSharpKeyword(string name)
        {
            string[] keywords =
            [
                "namespace", "class", "interface", "enum", "struct",
               "public", "private", "protected", "internal", "static",
               "return", "new", "null", "true", "false", "using", "try",
               "catch", "finally", "switch", "case", "default", "break", "continue"
            ];
            return keywords.Contains(name);
        }
        private static string ClassifyComplexityBucket(int complexity)
        {
            return complexity switch
            {
                <= 10 => "Low",
                <= 20 => "Medium",
                <= 30 => "High",
                _ => "Very High"
            };
        }
    }
}