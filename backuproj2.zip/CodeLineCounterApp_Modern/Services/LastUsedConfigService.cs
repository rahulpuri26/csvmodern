﻿using CodeLineCounterApp.Services.Interfaces;
using System.IO;
namespace CodeLineCounterApp.Services;
public class LastUsedConfigService : ILastUsedConfigService
{
    private const string FilePath = "last_used_config.txt";
    public string? GetLastUsedConfigPath()
    {
        return File.Exists(FilePath) ? File.ReadAllText(FilePath) : null;
    }
    public void SetLastUsedConfigPath(string path)
    {
        File.WriteAllText(FilePath, path);
    }
}