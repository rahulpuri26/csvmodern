using CodeLineCounterApp.Contracts;
using System.IO;
using System.Threading.Tasks;

namespace CodeLineCounterApp.Services;

public class LineCounterService : ILineCounter
{
    public async Task<int> CountLinesAsync(string filePath)
    {
        var lines = await File.ReadAllLinesAsync(filePath);
        return lines.Length;
    }
}