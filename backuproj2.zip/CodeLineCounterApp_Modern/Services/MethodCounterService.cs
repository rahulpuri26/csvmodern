using CodeLineCounterApp.Contracts;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
namespace CodeLineCounterApp.Services
{
    public class MethodCounterService : IMethodCounter
    {
        public Task<int> CountMethodsAsync(string code)
        {
            // Match typical C# method declarations (with or without modifiers)
            var pattern = @"(?:(?:public|private|protected|internal|static|virtual|override|async|sealed|extern)\s+)*\s*\w[\w<>,\[\]\s]*\s+\w+\s*\([^)]*\)\s*(?:\{|\=\>)";
            var matches = Regex.Matches(code, pattern);
            return Task.FromResult(matches.Count);
        }
    }
}