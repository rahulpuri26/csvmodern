﻿using CodeLineCounterApp.Contracts;
using CodeLineCounterApp.Models;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
namespace CodeLineCounterApp.Services
{
    public class ComplexityAnalyzerService : IComplexityAnalyzer
    {
        private static readonly string[] BranchingKeywords = [
           "if", "else if", "for", "foreach", "while", "case", "catch", "&&", "||", "?", "switch"
       ];
        private static readonly string[] CommonTypesToIgnore = [
           "int", "string", "float", "double", "decimal", "bool", "var", "object", "Task", "void"
       ];
        public Task<ComplexityResult> AnalyzeAsync(string filePath, string code)
        {
            int cyclomatic = CalculateCyclomaticComplexity(code);
            int coupling = CalculateClassCoupling(code, Path.GetFileNameWithoutExtension(filePath));
            var bucket = ClassifyComplexityBucket(cyclomatic);
            var result = new ComplexityResult
            {
                FileName = Path.GetFileName(filePath),
                CyclomaticComplexity = cyclomatic,
                ClassCoupling = coupling,
                ComplexityCategory = bucket
            };
            return Task.FromResult(result);
        }
        private static int CalculateCyclomaticComplexity(string code)
        {
            int matches = BranchingKeywords.Sum(keyword =>
                Regex.Matches(code, $@"\b{Regex.Escape(keyword)}\b").Count);
            return matches + 1;
        }
        private static int CalculateClassCoupling(string code, string currentClassName)
        {
            var typeMatches = Regex.Matches(code, @"\b[A-Z][a-zA-Z0-9_]*\b")
                .Cast<Match>()
                .Select(m => m.Value)
                .Where(name =>
                    name != currentClassName &&
                    !CommonTypesToIgnore.Contains(name) &&
                    !IsCSharpKeyword(name))
                .Distinct();
            return typeMatches.Count();
        }
        private static bool IsCSharpKeyword(string name)
        {
 
            string[] keywords = [
               "namespace", "class", "interface", "enum", "struct",
               "public", "private", "protected", "internal", "static",
               "return", "new", "null", "true", "false", "using", "try",
               "catch", "finally", "switch", "case", "default", "break", "continue"
           ];
            return keywords.Contains(name);
        }
        private static string ClassifyComplexityBucket(int complexity)
        {
            return complexity switch
            {
                <= 10 => "Low",
                <= 20 => "Medium",
                <= 30 => "High",
                _ => "Very High"
            };
        }
    }
}