﻿using CodeLineCounterApp.Contracts;
using CodeLineCounterApp.Helpers;
using CodeLineCounterApp.Models;
using Microsoft.Win32;
using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Forms;
using SaveFileDialog = System.Windows.Forms.SaveFileDialog;
using OpenFileDialog = Microsoft.Win32.OpenFileDialog;

namespace CodeLineCounterApp.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private readonly IFileAnalyzer _fileAnalyzer;
        private readonly ILoggerService _logger;
        public MainViewModel(IFileAnalyzer fileAnalyzer, ILoggerService logger)
        {
            _fileAnalyzer = fileAnalyzer;
            _logger = logger;
        }
        private string _rootPath = string.Empty;
        private bool _includeSubfolders = true;
        private string _manualExtensions = "";
        private string _manualExcludedPaths = "";
        private int _totalLineCount;
        private int _totalFileCount;
        private int _totalMethodCount;
        public string RootPath
        {
            get => _rootPath;
            set { _rootPath = value; OnPropertyChanged(); }
        }
        public bool IncludeSubfolders
        {
            get => _includeSubfolders;
            set { _includeSubfolders = value; OnPropertyChanged(); }
        }
        public string ManualExtensions
        {
            get => _manualExtensions;
            set { _manualExtensions = value; OnPropertyChanged(); }
        }
        public string ManualExcludedPaths
        {
            get => _manualExcludedPaths;
            set { _manualExcludedPaths = value; OnPropertyChanged(); }
        }
        public int TotalLineCount
        {
            get => _totalLineCount;
            set { _totalLineCount = value; OnPropertyChanged(); }
        }
        public int TotalFileCount
        {
            get => _totalFileCount;
            set { _totalFileCount = value; OnPropertyChanged(); }
        }
        public int TotalMethodCount
        {
            get => _totalMethodCount;
            set { _totalMethodCount = value; OnPropertyChanged(); }
        }
        public ObservableCollection<FileAnalysisResult> Results { get; } = new();
        public ICommand AnalyzeCommand => new RelayCommand(async _ => await AnalyzeAsync());
        public ICommand ExportCommand => new RelayCommand(_ => ExportCsv());
        public ICommand LoadJsonCommand => new RelayCommand(_ => LoadJson());
        public ICommand SaveJsonCommand => new RelayCommand(_ => SaveJson());
        public ICommand BrowseFolderCommand => new RelayCommand(_ => BrowseFolder());
        private async Task AnalyzeAsync()
        {
            try
            {
                Results.Clear();
                TotalFileCount = 0;
                TotalLineCount = 0;
                TotalMethodCount = 0;
                if (!Directory.Exists(RootPath)) return;
                var settings = new AppSettings
                {
                    IncludedExtensions = ManualExtensions
                        .Split(new[] { '\n', '\r', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(e => e.Trim())
                        .Where(e => e.StartsWith("."))
                        .ToList(),
                    ExcludedPaths = ManualExcludedPaths
                        .Split(new[] { '\n', '\r', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(e => e.Trim())
                        .ToList()
                };
                var results = await _fileAnalyzer.AnalyzeFilesAsync(settings, RootPath, IncludeSubfolders);
                foreach (var r in results)
                {
                    Results.Add(r);
                    TotalLineCount += r.LineCount;
                    TotalMethodCount += r.MethodCount;
                }
                TotalFileCount = results.Count;
                _logger.LogInfo("Analysis completed. {FileCount} files analyzed.", TotalFileCount);
            }
            catch (Exception ex)
            {
                _logger.LogError("Analysis failed: {Message}", ex.Message);
            }
        }
        private void ExportCsv()
        {
            var dialog = new SaveFileDialog { Filter = "CSV file (*.csv)|*.csv", FileName = "results.csv" };
            if (dialog.ShowDialog() != DialogResult.OK) return;
            using var writer = new StreamWriter(dialog.FileName);
            writer.WriteLine("FullPath,FileName,Extension,LineCount,MethodCount");
            foreach (var r in Results)
            {
                writer.WriteLine($"{r.FullPath},{r.FileName},{r.Extension},{r.LineCount},{r.MethodCount}");
            }
            writer.WriteLine($",,,Total Files,{TotalFileCount}");
            writer.WriteLine($",,,Total Lines,{TotalLineCount}");
            writer.WriteLine($",,,Total Methods,{TotalMethodCount}");
            _logger.LogInfo("CSV export completed.");
        }
        private void LoadJson()
        {
            var dialog = new OpenFileDialog { Filter = "JSON file (*.json)|*.json" };
            if (dialog.ShowDialog() != true) return;
            var json = File.ReadAllText(dialog.FileName);
            var config = JsonSerializer.Deserialize<AppSettings>(json);
            if (config == null) return;
            ManualExtensions = string.Join("\n", config.IncludedExtensions);
            ManualExcludedPaths = string.Join("\n", config.ExcludedPaths);
            _logger.LogInfo("Config loaded from JSON.");
        }
        private void SaveJson()
        {
            var dialog = new SaveFileDialog { Filter = "JSON file (*.json)|*.json", FileName = "config.json" };
            if (dialog.ShowDialog() != DialogResult.OK) return;
            var config = new AppSettings
            {
                IncludedExtensions = ManualExtensions
                    .Split(new[] { '\n', '\r', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(e => e.Trim()).ToList(),
                ExcludedPaths = ManualExcludedPaths
                    .Split(new[] { '\n', '\r', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(e => e.Trim()).ToList()
            };
            var json = JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(dialog.FileName, json);
            _logger.LogInfo("Config saved to JSON.");
        }
        private void BrowseFolder()
        {
            using var dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                RootPath = dialog.SelectedPath;
                _logger.LogInfo("Folder selected: {Path}", RootPath);
            }
        }
    }
}